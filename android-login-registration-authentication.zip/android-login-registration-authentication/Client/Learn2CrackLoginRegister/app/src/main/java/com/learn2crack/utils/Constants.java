package com.learn2crack.utils;

public class Constants {

    public static final String BASE_URL = "http://10.0.2.2:8080/api/v1/";
    public static final String TOKEN = "token";
    public static final String EMAIL = "email";
}
